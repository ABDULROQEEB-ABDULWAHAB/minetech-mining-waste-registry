# Proposed 10-week workplan

*Proposal for planning purposes. Dates depend on site authorisation and laboratory access.*

| Week | Activities |
|---|---|
| 1 | Secure site access and authorisation (owner, local authorities). Interview small-scale miners, operators and regulators about their waste-data needs. Write the sampling protocol and safety plan. |
| 2 | First field visit: collect and register samples. Refine the registry using user feedback. |
| 3 | Handheld XRF screening of all samples. Sample preparation. Submit a subset for laboratory confirmation and leach testing. |
| 4 | **Screening decision gate.** Classify samples (hazard / recovery potential / reuse candidate). Only samples that pass go forward to block casting. If none pass, the project continues as a characterisation and recovery-screening study. |
| 5 | Cast sample blocks and conventional control blocks (if the gate is passed). Begin curing. Physical characterisation of the material. |
| 6 | Early strength check on blocks. Enter laboratory results into the registry and update flags. |
| 7 | Second round of user feedback on registry outputs. |
| 8 | Repeat or extend testing where results are unclear. Prepare the technical review. |
| 9 | 28-day tests on blocks (strength, water absorption, durability where facilities permit). |
| 10 | Analysis, final report, presentation for technical review and incubation consideration. |

**Dependencies:** authorised site access, a handheld XRF, access to a laboratory for confirmatory and leach testing, and block-casting and testing facilities. If laboratory access is unavailable, the team builds out the registry and completes the feasibility assessment first.
