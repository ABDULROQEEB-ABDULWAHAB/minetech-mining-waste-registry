# Data schema and flag logic

Storage is SQLite (`data/registry.db`, created on first run, not committed).

## `samples`

| Field | Notes |
|---|---|
| `sample_code` | Generated, e.g. `MW-0001` |
| `source_name` | Required. Waste source, e.g. a spoil area or tailings heap |
| `state`, `latitude`, `longitude` | Location (decimal degrees) |
| `collected_on`, `collected_by` | ISO date, person |
| `material_type`, `depth_cm` | e.g. mine spoil, tailings; sampling depth |
| `authorisation_ref` | Reference to site owner / authority permission |
| `notes` | Free text |
| `is_demo` | 1 for synthetic demo rows |

## `results` (one row per measurement)

| Field | Notes |
|---|---|
| `sample_id` | Links to `samples` |
| `method` | pXRF, XRF-lab, ICP-OES, ICP-MS, AAS, Leach test, Block test, Other |
| `parameter` | Element symbol (Cr, Sn, ...) or a property (Compressive strength 28d, Water absorption) |
| `value`, `unit` | Concentrations in ppm, mg/kg, % or ppb are converted to ppm for flagging |
| `tested_on`, `device_or_lab`, `notes` | Provenance |

CSV import columns: `sample_code, method, parameter, value, unit` (required) plus `tested_on, device_or_lab, notes`.

## Flag logic (`registry.py`)

Only results from screening methods (listed in `config/flag_rules.json`) are used. For each element the most recent result wins.

- **HAZARD**: an element in `hazard_ppm` is at or above its screening level.
- **RECOVERY POTENTIAL**: an element in `recovery_ppm` is at or above its interest level.
- **REUSE CANDIDATE**: no hazard flag and every element in `required_for_reuse_screen` has been measured. Reads "leach test pending" until leach data exists. Never a safety clearance.
- **INSUFFICIENT DATA**: no screening results, or required elements are missing.

A sample can carry several flags (for example hazard and recovery potential together). A hazard flag blocks the reuse-candidate flag.

## Placeholder thresholds

`config/flag_rules.json` ships with invented numbers so the logic can be demonstrated. They must be replaced with values from applicable Nigerian regulatory guidance and the project's own lab data.
