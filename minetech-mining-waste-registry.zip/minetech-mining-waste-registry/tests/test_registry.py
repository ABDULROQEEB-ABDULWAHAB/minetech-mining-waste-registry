"""Run with:  python -m pytest -q   (or)   python tests/test_registry.py"""
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import registry as reg  # noqa: E402


def fresh():
    return reg.connect(":memory:"), reg.load_rules()


def table(conn, rules):
    return reg.flag_table(reg.samples_df(conn), reg.results_df(conn), rules).set_index("sample_code")


def test_sample_codes_are_sequential():
    conn, _ = fresh()
    assert reg.add_sample(conn, "Site X") == "MW-0001"
    assert reg.add_sample(conn, "Site X") == "MW-0002"


def test_source_name_required():
    conn, _ = fresh()
    try:
        reg.add_sample(conn, "  ")
        assert False, "should have raised"
    except ValueError:
        pass


def test_unknown_sample_rejected():
    conn, _ = fresh()
    try:
        reg.add_result(conn, "MW-9999", "pXRF", "Cr", 10, "ppm")
        assert False, "should have raised"
    except KeyError:
        pass


def test_hazard_flag_and_no_reuse_candidate():
    conn, rules = fresh()
    code = reg.add_sample(conn, "Site X")
    for el, v in (("Cr", 500), ("Pb", 10), ("As", 2)):
        reg.add_result(conn, code, "pXRF", el, v, "ppm")
    row = table(conn, rules).loc[code]
    assert row.hazard and not row.reuse_candidate


def test_reuse_candidate_needs_all_required_elements():
    conn, rules = fresh()
    code = reg.add_sample(conn, "Site X")
    reg.add_result(conn, code, "pXRF", "Cr", 10, "ppm")
    row = table(conn, rules).loc[code]
    assert row.insufficient_data and not row.reuse_candidate
    reg.add_result(conn, code, "pXRF", "Pb", 10, "ppm")
    reg.add_result(conn, code, "pXRF", "As", 2, "ppm")
    row = table(conn, rules).loc[code]
    assert row.reuse_candidate and "leach test pending" in row.screening_flags


def test_percent_units_converted():
    conn, rules = fresh()
    code = reg.add_sample(conn, "Site X")
    reg.add_result(conn, code, "ICP-OES", "Sn", 0.5, "%")  # 5000 ppm
    assert table(conn, rules).loc[code].recovery


def test_latest_result_wins():
    conn, rules = fresh()
    code = reg.add_sample(conn, "Site X")
    reg.add_result(conn, code, "pXRF", "Cr", 500, "ppm", tested_on="2026-01-01")
    reg.add_result(conn, code, "ICP-OES", "Cr", 20, "ppm", tested_on="2026-02-01")
    assert not table(conn, rules).loc[code].hazard


def test_non_screening_methods_ignored():
    conn, rules = fresh()
    code = reg.add_sample(conn, "Site X")
    reg.add_result(conn, code, "Block test", "Compressive strength 28d", 4.0, "MPa")
    assert table(conn, rules).loc[code].insufficient_data


def test_demo_loads_once_and_clears():
    conn, rules = fresh()
    assert reg.load_demo(conn) == 7
    assert reg.load_demo(conn) == 0
    t = table(conn, rules)
    assert t.loc["MW-0001"].reuse_candidate
    assert t.loc["MW-0002"].hazard
    assert t.loc["MW-0003"].recovery and t.loc["MW-0003"].reuse_candidate
    assert t.loc["MW-0004"].hazard and t.loc["MW-0004"].recovery
    assert t.loc["MW-0005"].insufficient_data
    assert t.loc["MW-0006"].insufficient_data
    assert reg.clear_demo(conn) == 7
    assert reg.samples_df(conn).empty


def test_csv_import_reports_bad_rows():
    conn, _ = fresh()
    code = reg.add_sample(conn, "Site X")
    df = pd.DataFrame([
        {"sample_code": code, "method": "pXRF", "parameter": "Cr", "value": 10, "unit": "ppm"},
        {"sample_code": "MW-9999", "method": "pXRF", "parameter": "Cr", "value": 10, "unit": "ppm"},
    ])
    ok, errors = reg.import_results(conn, df)
    assert ok == 1 and len(errors) == 1


if __name__ == "__main__":
    tests = [v for k, v in dict(globals()).items() if k.startswith("test_")]
    for t in tests:
        t()
        print("PASS", t.__name__)
    print(f"{len(tests)} tests passed")
