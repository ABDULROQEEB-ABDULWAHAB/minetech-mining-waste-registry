"""Core logic for the Mining Waste Sample Registry: SQLite storage and screening flags.

Deliberately free of UI code so it can be tested and reused (CLI, API, notebook).
"""
from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import pandas as pd

BASE = Path(__file__).parent
DB_PATH = BASE / "data" / "registry.db"
RULES_PATH = BASE / "config" / "flag_rules.json"
DEMO_DIR = BASE / "data" / "demo"

METHODS = ["pXRF", "XRF-lab", "ICP-OES", "ICP-MS", "AAS", "Leach test", "Block test", "Other"]
UNITS = ["ppm", "mg/kg", "%", "ppb", "MPa", "%  (water absorption)", "other"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS samples (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sample_code TEXT UNIQUE,
    source_name TEXT NOT NULL,
    state TEXT DEFAULT 'Niger',
    latitude REAL,
    longitude REAL,
    collected_on TEXT,
    collected_by TEXT,
    material_type TEXT,
    depth_cm REAL,
    authorisation_ref TEXT,
    notes TEXT,
    is_demo INTEGER DEFAULT 0,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS results (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sample_id INTEGER NOT NULL REFERENCES samples(id) ON DELETE CASCADE,
    method TEXT NOT NULL,
    parameter TEXT NOT NULL,
    value REAL NOT NULL,
    unit TEXT NOT NULL,
    tested_on TEXT,
    device_or_lab TEXT,
    notes TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_results_sample ON results(sample_id);
"""

RESULT_COLUMNS = ["sample_code", "method", "parameter", "value", "unit",
                  "tested_on", "device_or_lab", "notes"]


# ---------------------------------------------------------------- storage ---
def connect(db_path=None) -> sqlite3.Connection:
    path = str(db_path) if db_path else str(DB_PATH)
    if path != ":memory:":
        Path(path).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.executescript(SCHEMA)
    return conn


def add_sample(conn, source_name, *, state="Niger", latitude=None, longitude=None,
               collected_on=None, collected_by=None, material_type=None, depth_cm=None,
               authorisation_ref=None, notes=None, is_demo=False) -> str:
    """Insert a sample and return its generated code (e.g. MW-0001)."""
    if not source_name or not str(source_name).strip():
        raise ValueError("source_name is required")
    cur = conn.execute(
        """INSERT INTO samples (source_name, state, latitude, longitude, collected_on,
               collected_by, material_type, depth_cm, authorisation_ref, notes, is_demo)
           VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (str(source_name).strip(), state, latitude, longitude, collected_on, collected_by,
         material_type, depth_cm, authorisation_ref, notes, int(bool(is_demo))),
    )
    code = f"MW-{cur.lastrowid:04d}"
    conn.execute("UPDATE samples SET sample_code = ? WHERE id = ?", (code, cur.lastrowid))
    conn.commit()
    return code


def _sample_id(conn, code) -> int:
    row = conn.execute("SELECT id FROM samples WHERE sample_code = ?", (code,)).fetchone()
    if row is None:
        raise KeyError(f"Unknown sample code: {code}")
    return row["id"]


def add_result(conn, sample_code, method, parameter, value, unit,
               tested_on=None, device_or_lab=None, notes=None) -> None:
    if not method or not parameter or not unit:
        raise ValueError("method, parameter and unit are required")
    conn.execute(
        """INSERT INTO results (sample_id, method, parameter, value, unit,
               tested_on, device_or_lab, notes) VALUES (?,?,?,?,?,?,?,?)""",
        (_sample_id(conn, sample_code), str(method).strip(), str(parameter).strip(),
         float(value), str(unit).strip(), tested_on, device_or_lab, notes),
    )
    conn.commit()


def import_results(conn, df: pd.DataFrame):
    """Bulk-import a results table. Returns (n_imported, list_of_error_strings)."""
    missing = [c for c in ("sample_code", "method", "parameter", "value", "unit") if c not in df.columns]
    if missing:
        return 0, [f"Missing required column(s): {', '.join(missing)}"]
    ok, errors = 0, []
    for i, row in enumerate(df.to_dict("records"), start=2):  # row 1 = header
        row = {k: (None if pd.isna(v) else v) for k, v in row.items()}
        try:
            add_result(conn, row["sample_code"], row["method"], row["parameter"], row["value"],
                       row["unit"], row.get("tested_on"), row.get("device_or_lab"), row.get("notes"))
            ok += 1
        except (KeyError, ValueError, TypeError) as exc:
            errors.append(f"Row {i}: {exc}")
    return ok, errors


def samples_df(conn) -> pd.DataFrame:
    return pd.read_sql_query("SELECT * FROM samples ORDER BY id", conn)


def results_df(conn) -> pd.DataFrame:
    return pd.read_sql_query(
        """SELECT r.id, s.sample_code, r.method, r.parameter, r.value, r.unit,
                  r.tested_on, r.device_or_lab, r.notes
           FROM results r JOIN samples s ON s.id = r.sample_id ORDER BY r.id""", conn)


# ------------------------------------------------------------------ flags ---
def load_rules(path=None) -> dict:
    with open(path or RULES_PATH, encoding="utf-8") as fh:
        return json.load(fh)


def to_ppm(value, unit):
    """Convert a concentration to ppm; return None if the unit is not a concentration."""
    u = str(unit).strip().lower()
    if u in ("ppm", "mg/kg"):
        return float(value)
    if u == "%":
        return float(value) * 10_000
    if u == "ppb":
        return float(value) / 1_000
    return None


def _flags_for(grp, rules) -> list[dict]:
    """Screening flags for one sample. These are triage aids, NOT safety determinations."""
    if grp is None or grp.empty:
        return [{"type": "INSUFFICIENT_DATA", "label": "INSUFFICIENT DATA (no results)"}]

    screen = grp[grp["method"].isin(rules["screening_methods"])].copy()
    screen["ppm"] = [to_ppm(v, u) for v, u in zip(screen["value"], screen["unit"])]
    screen = screen.dropna(subset=["ppm"])
    if screen.empty:
        return [{"type": "INSUFFICIENT_DATA", "label": "INSUFFICIENT DATA (no screening results)"}]
    screen["parameter"] = screen["parameter"].str.strip().str.capitalize()
    screen["tested_on"] = screen["tested_on"].fillna("")
    latest = screen.sort_values(["tested_on", "id"]).groupby("parameter").tail(1)
    latest = latest.set_index("parameter")["ppm"]

    flags = []
    hazards = [(el, latest[el], lim) for el, lim in rules["hazard_ppm"].items()
               if el in latest.index and latest[el] >= lim]
    for el, val, lim in hazards:
        flags.append({"type": "HAZARD", "label": f"HAZARD: {el} {val:g} ppm (>= {lim:g})"})

    for el, lim in rules["recovery_ppm"].items():
        if el in latest.index and latest[el] >= lim:
            flags.append({"type": "RECOVERY", "label": f"RECOVERY POTENTIAL: {el} {latest[el]:g} ppm (>= {lim:g})"})

    if not hazards:
        missing = [el for el in rules["required_for_reuse_screen"] if el not in latest.index]
        if missing:
            flags.append({"type": "INSUFFICIENT_DATA",
                          "label": f"INSUFFICIENT DATA (missing: {', '.join(missing)})"})
        else:
            has_leach = grp["method"].str.lower().str.contains("leach").any()
            note = "leach data recorded; review" if has_leach else "screening only; leach test pending"
            flags.append({"type": "REUSE_CANDIDATE", "label": f"REUSE CANDIDATE ({note})"})
    return flags


def flag_table(samples: pd.DataFrame, results: pd.DataFrame, rules: dict) -> pd.DataFrame:
    by_code = {c: g for c, g in results.groupby("sample_code")} if not results.empty else {}
    rows = []
    for code in samples["sample_code"]:
        fl = _flags_for(by_code.get(code), rules)
        types = {f["type"] for f in fl}
        rows.append({
            "sample_code": code,
            "screening_flags": " | ".join(f["label"] for f in fl),
            "hazard": "HAZARD" in types,
            "recovery": "RECOVERY" in types,
            "reuse_candidate": "REUSE_CANDIDATE" in types,
            "insufficient_data": "INSUFFICIENT_DATA" in types,
        })
    return pd.DataFrame(rows, columns=["sample_code", "screening_flags", "hazard", "recovery",
                                       "reuse_candidate", "insufficient_data"])


# ------------------------------------------------------------------- demo ---
def _clean(record: dict) -> dict:
    return {k: (None if pd.isna(v) else v) for k, v in record.items()}


def load_demo(conn) -> int:
    """Load SYNTHETIC demo data (idempotent). Returns number of samples added."""
    if conn.execute("SELECT COUNT(*) FROM samples WHERE is_demo = 1").fetchone()[0]:
        return 0
    refmap = {}
    for rec in pd.read_csv(DEMO_DIR / "samples.csv").to_dict("records"):
        rec = _clean(rec)
        ref, name = rec.pop("demo_ref"), rec.pop("source_name")
        refmap[ref] = add_sample(conn, name, is_demo=True, **rec)
    for rec in pd.read_csv(DEMO_DIR / "results.csv").to_dict("records"):
        rec = _clean(rec)
        add_result(conn, refmap[rec["demo_ref"]], rec["method"], rec["parameter"], rec["value"],
                   rec["unit"], rec.get("tested_on"), rec.get("device_or_lab"), rec.get("notes"))
    return len(refmap)


def clear_demo(conn) -> int:
    cur = conn.execute("DELETE FROM samples WHERE is_demo = 1")
    conn.commit()
    return cur.rowcount
