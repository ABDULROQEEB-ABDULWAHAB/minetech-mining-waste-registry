"""Streamlit front-end for the Mining Waste Sample Registry (prototype).

Run:  streamlit run app.py
"""
from datetime import date

import pandas as pd
import streamlit as st

import registry as reg

st.set_page_config(page_title="Mining Waste Sample Registry", page_icon="⛏️", layout="wide")

conn = reg.connect()
rules = reg.load_rules()
samples = reg.samples_df(conn)
results = reg.results_df(conn)
flags = reg.flag_table(samples, results, rules)


def parse_float(text):
    text = (text or "").strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        st.error(f"'{text}' is not a number.")
        st.stop()


# ---------------------------------------------------------------- sidebar ---
page = st.sidebar.radio("Go to", ["Browse & flags", "Register sample", "Add results", "Map", "About"])
st.sidebar.divider()
st.sidebar.caption("Demo data (synthetic)")
if st.sidebar.button("Load synthetic demo data"):
    n = reg.load_demo(conn)
    st.session_state["flash"] = f"Loaded {n} synthetic demo samples." if n else "Demo data already loaded."
    st.rerun()
if st.sidebar.button("Clear demo data"):
    st.session_state["flash"] = f"Removed {reg.clear_demo(conn)} demo samples."
    st.rerun()

if "flash" in st.session_state:
    st.success(st.session_state.pop("flash"))
if not samples.empty and samples["is_demo"].any():
    st.warning("Synthetic demo data is loaded. These values are invented to show how the "
               "registry works and are NOT real measurements.")

# ------------------------------------------------------------------ pages ---
if page == "Browse & flags":
    st.title("Mining Waste Sample Registry")
    st.caption("Prototype. Flags are screening aids to prioritise follow-up testing, "
               "not safety determinations. No material is assumed safe until tested.")
    if samples.empty:
        st.info("No samples yet. Register one, or load the synthetic demo data from the sidebar.")
        st.stop()

    df = samples.merge(flags, on="sample_code")
    q = st.text_input("Search (code, source, material, notes)")
    wanted = st.multiselect("Filter by flag", ["Hazard", "Recovery potential", "Reuse candidate",
                                               "Insufficient data"])
    if q:
        hay = df[["sample_code", "source_name", "material_type", "notes"]].fillna("").agg(" ".join, axis=1)
        df = df[hay.str.contains(q, case=False, regex=False)]
    colmap = {"Hazard": "hazard", "Recovery potential": "recovery",
              "Reuse candidate": "reuse_candidate", "Insufficient data": "insufficient_data"}
    if wanted:
        mask = pd.Series(False, index=df.index)
        for w in wanted:
            mask |= df[colmap[w]]
        df = df[mask]

    show = ["sample_code", "source_name", "material_type", "collected_on", "screening_flags"]
    st.dataframe(df[show], hide_index=True)
    st.download_button("Download table (CSV)", df.drop(columns=["id"]).to_csv(index=False),
                       "samples.csv", "text/csv")

    st.subheader("Sample detail")
    if not df.empty:
        code = st.selectbox("Sample", df["sample_code"])
        st.write(df[df["sample_code"] == code].drop(columns=["id", "is_demo"]).T.rename(columns=lambda _: ""))
        st.dataframe(results[results["sample_code"] == code].drop(columns=["id", "sample_code"]),
                     hide_index=True)

elif page == "Register sample":
    st.title("Register a sample")
    st.caption("Record where a sample came from and that access was authorised.")
    with st.form("register"):
        source = st.text_input("Source name *", placeholder="e.g. spoil area, tailings heap")
        c1, c2 = st.columns(2)
        state = c1.text_input("State", value="Niger")
        material = c2.text_input("Material type", placeholder="e.g. mine spoil, tailings")
        c3, c4, c5 = st.columns(3)
        lat = c3.text_input("Latitude (decimal)")
        lon = c4.text_input("Longitude (decimal)")
        depth = c5.text_input("Depth (cm)")
        c6, c7 = st.columns(2)
        when = c6.date_input("Collected on", value=date.today())
        who = c7.text_input("Collected by")
        auth = st.text_input("Authorisation reference", placeholder="site owner / authority permission ref")
        notes = st.text_area("Notes")
        submitted = st.form_submit_button("Register sample")
    if submitted:
        if not source.strip():
            st.error("Source name is required.")
        else:
            code = reg.add_sample(conn, source, state=state, latitude=parse_float(lat),
                                  longitude=parse_float(lon), collected_on=when.isoformat(),
                                  collected_by=who or None, material_type=material or None,
                                  depth_cm=parse_float(depth), authorisation_ref=auth or None,
                                  notes=notes or None)
            st.success(f"Registered sample {code}.")
            if not auth.strip():
                st.warning("No authorisation reference recorded. Confirm site access is authorised.")

elif page == "Add results":
    st.title("Add test results")
    if samples.empty:
        st.info("Register a sample first.")
        st.stop()
    tab_one, tab_csv = st.tabs(["Single result", "Upload CSV"])
    with tab_one:
        with st.form("result"):
            code = st.selectbox("Sample", samples["sample_code"])
            c1, c2, c3, c4 = st.columns(4)
            method = c1.selectbox("Method", reg.METHODS)
            param = c2.text_input("Parameter", placeholder="e.g. Cr, Sn, Compressive strength 28d")
            value = c3.number_input("Value", value=0.0, format="%.4f")
            unit = c4.selectbox("Unit", reg.UNITS)
            c5, c6 = st.columns(2)
            tested = c5.date_input("Tested on", value=date.today())
            device = c6.text_input("Device / lab")
            note = st.text_input("Notes")
            go = st.form_submit_button("Add result")
        if go:
            if not param.strip():
                st.error("Parameter is required.")
            else:
                reg.add_result(conn, code, method, param, value, unit, tested.isoformat(),
                               device or None, note or None)
                st.success(f"Added {param} for {code}.")
    with tab_csv:
        st.write("Required columns: " + ", ".join(reg.RESULT_COLUMNS[:5])
                 + ". Optional: tested_on, device_or_lab, notes.")
        up = st.file_uploader("Results CSV", type="csv")
        if up is not None:
            df = pd.read_csv(up)
            st.dataframe(df, hide_index=True)
            if st.button("Import these results"):
                ok, errors = reg.import_results(conn, df)
                st.success(f"Imported {ok} result(s).")
                for e in errors:
                    st.error(e)

elif page == "Map":
    st.title("Sample map")
    geo = samples.dropna(subset=["latitude", "longitude"])
    if geo.empty:
        st.info("No samples with coordinates yet.")
    else:
        st.map(geo[["latitude", "longitude"]])

else:
    st.title("About")
    st.markdown(
        "A prototype sample-to-decision registry for mining waste, built for the Pan-African "
        "MineTech Exploration Technology Pre-Incubation Programme. See the README and `docs/` "
        "for the problem, plan and screening logic.\n\n"
        "**Flags** combine pXRF/lab screening results with configurable rules in "
        "`config/flag_rules.json`. The shipped thresholds are placeholders. A 'reuse candidate' "
        "flag only means no screening exceedance was found; it is never a safety clearance."
    )
